export type ReasoningLabelState = 'active' | 'active-timed' | 'complete'

export interface ParsedReasoningLabel {
  state: ReasoningLabelState
  duration: string
}

export interface ReasoningWords {
  active: string
  complete: string
}

export const DEFAULT_WORDS: ReasoningWords = {
  active: 'Thinking',
  complete: 'Thought',
}

export function normalizeWord(value: unknown, fallback: string): string {
  if (typeof value !== 'string') return fallback
  const normalized = value.trim().replace(/\s+/g, ' ')
  return normalized || fallback
}

export function parseNativeReasoningLabel(text: string): ParsedReasoningLabel | null {
  const value = text.trim()
  const completed = /^Thought\s+for\s+(.+)$/i.exec(value)
  if (completed) return { state: 'complete', duration: completed[1]!.trim() }

  const activeTimed = /^Thinking\s+for\s+(.+)$/i.exec(value)
  if (activeTimed) return { state: 'active-timed', duration: activeTimed[1]!.trim() }

  if (/^Thinking$/i.test(value)) return { state: 'active', duration: '' }
  return null
}

export function formatReasoningLabel(parsed: ParsedReasoningLabel, words: ReasoningWords): string {
  if (parsed.state === 'complete') return `${words.complete} for ${parsed.duration}`
  if (parsed.state === 'active-timed') return `${words.active} for ${parsed.duration}`
  return words.active
}
