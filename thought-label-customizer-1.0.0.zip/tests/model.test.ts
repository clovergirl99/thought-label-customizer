import { describe, expect, test } from 'bun:test'
import { DEFAULT_WORDS, formatReasoningLabel, normalizeWord, parseNativeReasoningLabel } from '../src/model'

describe('reasoning label customization', () => {
  test('recognizes every Lumiverse reasoning label state', () => {
    expect(parseNativeReasoningLabel('Thinking')).toEqual({ state: 'active', duration: '' })
    expect(parseNativeReasoningLabel('Thinking for 4s')).toEqual({ state: 'active-timed', duration: '4s' })
    expect(parseNativeReasoningLabel('Thought for 1m 12s')).toEqual({ state: 'complete', duration: '1m 12s' })
  })

  test('preserves durations while replacing only the wording', () => {
    expect(formatReasoningLabel({ state: 'active', duration: '' }, { active: 'Dreaming', complete: 'Dreamed' })).toBe('Dreaming')
    expect(formatReasoningLabel({ state: 'active-timed', duration: '8s' }, { active: 'Dreaming', complete: 'Dreamed' })).toBe('Dreaming for 8s')
    expect(formatReasoningLabel({ state: 'complete', duration: '18s' }, { active: 'Dreaming', complete: 'Dreamed' })).toBe('Dreamed for 18s')
  })

  test('blank values restore the Lumiverse defaults', () => {
    expect(normalizeWord('   ', DEFAULT_WORDS.active)).toBe('Thinking')
    expect(normalizeWord('  Pondering  deeply ', DEFAULT_WORDS.active)).toBe('Pondering deeply')
  })
})
